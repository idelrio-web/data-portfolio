# Free Online Portfolio Data Pack (CSV)

This pack contains **three project-ready datasets** you can use with **DuckDB Web Shell (SQL in browser)** and **Looker Studio (dashboarding)**.

## Files included

### Project 1 — Sales (relational)
- `project1_orders.csv` (fact table)
- `project1_customers.csv` (dimension)
- `project1_products.csv` (dimension)
- `project1_returns.csv` (optional extra)

**How they join**
- `orders.customer_id` → `customers.customer_id`
- `orders.product_id` → `products.product_id`
- `returns.order_id` → `orders.order_id`

**Common metrics**
- Revenue = quantity * unit_price * (1 - discount_pct)
- Cost = quantity * unit_cost
- Profit = Revenue - Cost
- Profit Margin % = Profit / Revenue

### Project 2A — Customer churn (single table)
- `project2_telco_churn_like.csv`

### Project 2B — Ops KPI (tickets; single table)
- `project2_ops_tickets.csv`

---

## Column dictionaries

### `project1_orders.csv`
- order_id (text)
- order_date (YYYY-MM-DD)
- ship_date (YYYY-MM-DD)
- customer_id (text)
- product_id (text)
- quantity (int)
- unit_price (decimal)
- discount_pct (decimal; 0 to 0.20)
- region (text)
- state (2-letter)
- channel (Online / In-Store / Partner)

### `project1_customers.csv`
- customer_id (text)
- customer_name (text)
- segment (Consumer / Corporate / Home Office)
- city (text)
- state (2-letter)
- region (text)
- signup_date (YYYY-MM-DD)

### `project1_products.csv`
- product_id (text)
- product_name (text)
- category (Furniture / Office Supplies / Technology)
- subcategory (text)
- unit_cost (decimal)
- list_price (decimal)

### `project1_returns.csv`
- order_id (text)
- returned_flag (1)
- return_date (YYYY-MM-DD)

### `project2_telco_churn_like.csv`
- customer_id (text)
- tenure_months (int)
- contract_type (Month-to-month / One year / Two year)
- internet_service (DSL / Fiber optic / None)
- paperless_billing (Yes/No)
- tech_support (Yes/No)
- payment_method (text)
- monthly_charges (decimal)
- total_charges (decimal)
- churn (Yes/No)

### `project2_ops_tickets.csv`
- ticket_id (text)
- created_at (ISO datetime)
- resolved_at (ISO datetime)
- priority (Low/Medium/High/Critical)
- category (text)
- channel (Email/Chat/Phone/Web)
- agent (text)
- sla_hours (int)
- status (Resolved)
- csat_positive (0/1)

---
