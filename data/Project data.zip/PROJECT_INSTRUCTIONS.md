# Portfolio Project Roadmap (Free + Online Tools)

Use:
- DuckDB Web Shell for SQL
- Google Sheets for cleaning
- Looker Studio for dashboards

## Project 1 (Sales KPI Dashboard)
Files: project1_orders.csv, project1_customers.csv, project1_products.csv, project1_returns.csv

Deliverables:
1) SQL file with queries (monthly revenue, category performance, top products, returns rate)
2) Dashboard (Looker Studio) with KPIs + trends + breakdowns
3) 1-page executive summary (3 insights + 3 recommendations)

## Project 2A (Churn) OR 2B (Ops KPI)
Pick one file:
- Churn: project2_telco_churn_like.csv
- Ops: project2_ops_tickets.csv

Deliverables:
Same: SQL + dashboard + executive summary

## Real Project (Volunteer)
Use the included template (you can copy Project 1 structure). Your goal is a single-page dashboard and a 1-page report.
