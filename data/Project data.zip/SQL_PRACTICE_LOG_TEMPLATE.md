# SQL Practice Log (Week 1)

**Goal:** Load a CSV, run queries, take screenshots of results, and paste them here.

## Dataset for Week 1
Use `project1_orders.csv` (or any file in this pack).

---

## How to load (DuckDB Web Shell)
1) Upload the CSV into the DuckDB Web Shell (or drag & drop).
2) Run:
```sql
SELECT * FROM read_csv_auto('project1_orders.csv') LIMIT 5;
```

---

## 10 queries to complete (paste screenshots under each)

### 1) Preview rows
```sql
SELECT * FROM read_csv_auto('project1_orders.csv') LIMIT 10;
```

### 2) Filter with WHERE (example: only West region)
```sql
SELECT * 
FROM read_csv_auto('project1_orders.csv')
WHERE region = 'West'
LIMIT 20;
```

### 3) GROUP BY + SUM (revenue by region)
```sql
SELECT region,
       SUM(quantity * unit_price * (1 - discount_pct)) AS revenue
FROM read_csv_auto('project1_orders.csv')
GROUP BY region
ORDER BY revenue DESC;
```

### 4) ORDER BY + LIMIT (top states by revenue)
```sql
SELECT state,
       SUM(quantity * unit_price * (1 - discount_pct)) AS revenue
FROM read_csv_auto('project1_orders.csv')
GROUP BY state
ORDER BY revenue DESC
LIMIT 10;
```

### 5) Date extraction (monthly revenue)
```sql
SELECT strftime(CAST(order_date AS DATE), '%Y-%m') AS month,
       SUM(quantity * unit_price * (1 - discount_pct)) AS revenue
FROM read_csv_auto('project1_orders.csv')
GROUP BY month
ORDER BY month;
```

### 6) JOIN (orders + products to compute profit)
```sql
WITH o AS (SELECT * FROM read_csv_auto('project1_orders.csv')),
     p AS (SELECT * FROM read_csv_auto('project1_products.csv'))
SELECT p.category,
       SUM(o.quantity * o.unit_price * (1 - o.discount_pct)) AS revenue,
       SUM(o.quantity * p.unit_cost) AS cost,
       SUM(o.quantity * o.unit_price * (1 - o.discount_pct)) - SUM(o.quantity * p.unit_cost) AS profit
FROM o
JOIN p ON o.product_id = p.product_id
GROUP BY p.category
ORDER BY profit DESC;
```

### 7) LEFT JOIN (returns rate by region)
```sql
WITH o AS (SELECT * FROM read_csv_auto('project1_orders.csv')),
     r AS (SELECT * FROM read_csv_auto('project1_returns.csv'))
SELECT o.region,
       COUNT(*) AS orders,
       SUM(CASE WHEN r.returned_flag = 1 THEN 1 ELSE 0 END) AS returns,
       ROUND(100.0 * SUM(CASE WHEN r.returned_flag = 1 THEN 1 ELSE 0 END) / COUNT(*), 2) AS return_rate_pct
FROM o
LEFT JOIN r ON o.order_id = r.order_id
GROUP BY o.region
ORDER BY return_rate_pct DESC;
```

### 8) CASE WHEN (discount buckets)
```sql
SELECT CASE 
         WHEN discount_pct = 0 THEN '0%'
         WHEN discount_pct <= 0.05 THEN '1–5%'
         WHEN discount_pct <= 0.10 THEN '6–10%'
         WHEN discount_pct <= 0.15 THEN '11–15%'
         ELSE '16–20%'
       END AS discount_bucket,
       COUNT(*) AS orders
FROM read_csv_auto('project1_orders.csv')
GROUP BY discount_bucket
ORDER BY orders DESC;
```

### 9) Multi-step (customers by segment & revenue)
```sql
WITH o AS (SELECT * FROM read_csv_auto('project1_orders.csv')),
     c AS (SELECT * FROM read_csv_auto('project1_customers.csv'))
SELECT c.segment,
       COUNT(DISTINCT o.customer_id) AS customers,
       SUM(o.quantity * o.unit_price * (1 - o.discount_pct)) AS revenue
FROM o
JOIN c ON o.customer_id = c.customer_id
GROUP BY c.segment
ORDER BY revenue DESC;
```

### 10) Quality check (missing/odd values)
```sql
SELECT 
  SUM(CASE WHEN order_date IS NULL THEN 1 ELSE 0 END) AS missing_order_date,
  SUM(CASE WHEN quantity <= 0 THEN 1 ELSE 0 END) AS bad_quantity,
  MIN(discount_pct) AS min_discount,
  MAX(discount_pct) AS max_discount
FROM read_csv_auto('project1_orders.csv');
```

---
## Screenshots
Paste your screenshots under each query section above.
